*****************************
Policy Description
*****************************

Policy:  ICMPRqstImbalDetect

Purpose: This policy provides a CLEAR-Flow monitoring example that 
inspects Internet Control Message Protocol (ICMP) requests to spot
potential route down or IP address sweeps that may indicate network
usage policy violations or hacker activity.

This policy counts all received ICMP requests, as well as all 
received unreachable ICMP requests.  When the ratio of all ICMP 
requests to ICMP unreachable request exceeds 10,000 over 5 seconds
then (1) all ICMP unreachable request traffic is mirrored, (2) an
SNMP trap is issued, and (3) a message indicating the situation
is written to the syslog.

CLEAR-Flow is supported on the BlackDiamond(R) 10808, 
BlackDiamond 12800R series, BlackDiamond 12804C, BlackDiamond 8800 "c" series, 
and Summit(R) X450a switches.    

For additonal information on CLEAR-Flow policies, please refer to 
the ExtremeXOS(TM) Concetps Guide.  

*****************************
Infrastructure Requirements
*****************************
ExtremeXOS(TM) 12.0
CLEAR-Flow compatible Extreme Networks core and aggregate switches.